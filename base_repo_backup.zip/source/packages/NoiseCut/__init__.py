# -----------------------------------------------------------------------------
# NoiseCut - AGPLv3
#
# This file is part of the NoiseCut library. For licensing information see the
# accompanying file `LICENSE`.
#
# The NoiseCut Developers, 21st century
# -----------------------------------------------------------------------------

from .noisecut import *  # noqa
